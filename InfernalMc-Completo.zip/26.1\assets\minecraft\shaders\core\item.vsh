#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightColor; // Added for Unshaded state
out vec4 baseColor;  // Added for Emissive state
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    // Sample the block light (torches, glowstone, etc.)
    vec4 blockLight = sample_lightmap(Sampler2, UV2);

    // Default Shaded: Directional light + normal + block light
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * blockLight;
    
    // Unshaded: Ignores directional light, but reacts to block light
    lightColor = Color * blockLight;
    
    // Emissive: Pure color, ignores all lighting
    baseColor = Color;

    texCoord0 = UV0;
}